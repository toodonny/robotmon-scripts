importJS('RBM-0.0.3');
importJS('/sdcard/Download/Robotmon/scripts/com.donny.coinforfriend/lib/donnyLib.js');

////COMMAND START/STOP
//runSwitch = 0;

////ROBOTMON DEFAULT SETTING
var config = {
    appName: 'com.donny.coinforfriend',
    oriScreenWidth: 1080, // source
    oriScreenHeight: 2280,
    oriVirtualButtonHeight: 0,
    oriResizeFactor: 1,
    eventDelay: 50,
    imageThreshold: 1,
    imageQuality: 100,
    resizeFactor: 1, // small -> quickly
    scriptDir: 'scripts/com.donny.coinforfriend/images',
    isRunning: false,
  };
  var rbm = new RBM(config);
  rbm.init();

//==============================功能性function=====================================//

function useReturn(choiceF){          //各項回授點檢查
	if (!config.isRunning) return false;
	//console.log('各項升級限制條件');

	switch (choiceF) {
		case  1: return CheckImageTap( 625,   10, 710,   70, 0.95, 'mainpagebutton.png', 1, 1, 1, 50, 2, 0);    return;   //右上功能圖示 OK
		case  2:
			rbm.keepScreenshotPartial( 440, 10, 570, 70);
			var Img1 = rbm.findImage('speedx2.png', 0.90);        //檢查2倍速圖示
			var Img2 = rbm.findImage('speedx3.png', 0.90);        //檢查3倍速圖示
			rbm.releaseScreenshot();

			if(Img1 != undefined || Img2 != undefined){return true;}
			return false;

		case  3: return CheckImageTap( 310,  590, 410,  690, 0.85, 'ADbox.png', 1, 1, 1, 50, 2);             return;   //檢查寶箱看廣告  OK
		case  4: return CheckImageTap(   0,  580, 110,  820, 0.85, 'speedX2icon_3.png', 1, 1, 1, 50, 2);       return;   //2倍速選單圖示 OK
		case  5: return CheckImageTap( 220,  560, 360,  700, 0.85, 'herostore_str.png', 1, 1, 1, 50, 2, 0);     return;   //英雄商店文字
		case  6: return CheckImageTap( 220,  600, 340,  700, 0.85, 'lvupallhero2.png', 1, 1, 1, 50, 2, 0);      return;   //英雄頁面全英雄升級文字
		case  7: return
		case  8: return CheckImageTap( 110, 1210, 310, 1280, 0.85, 'guildChaticon.png', 1, 1, 1, 50, 2);     return;   //工會聊天室圖示
		case  9: return CheckImageTap( 270,   60, 500,  375, 0.85, 'dailystr.png', 1, 1, 1, 50, 2);          return;   //每日獎勵字樣

		case 10: return CheckImageTap( 550,  800, 700,  880, 0.85, 'timeplaying.png', 1, 1, 1, 50, 2);       return;   //看廣告金幣(開啟)
		case 11: return CheckImageTap( 650,   20, 700,   65, 0.85, 'ADdebug1.png', 1, 1, 1, 50, 2);          return;   //廣告右上固定
		case 12: return CheckImageTap( 680,    0, 720,   33, 0.85, 'AD_XX_01.png', 1, 1, 1, 50, 2);          return;   //AD_XX_01

		case 13: return CheckImageTap( 270,  510, 380,  560, 0.85, 'herobookicon.png', 1, 1, 1, 50, 2);      return;   //英雄冊文字
		case 14: return CheckImageTap(  25, 1180, 160, 1280, 0.85, 'herowepon.png', 1, 1, 1, 50, 2);         return;   //英雄冊文字

		case 15: return CheckImageTap( 440,   10, 570,   70, 0.95, 'speedx3.png', 1, 1, 1, 50, 2);           return;   //檢查3倍速圖示 OK

		case 21: return CheckImageTap(  45,  530, 110,  590, 0.80, 'retreatBoss02.png', 1, 1, 1, 50, 2);       return;  //BOSS戰鬥，撤退鈕
		case 22: return CheckImageTap( 135,  510, 560,  560, 0.80, 'bossticks.png', 1, 1, 1, 50, 2);         return;  //地城BOSS選關(門票字樣)
		case 23: return CheckImageTap2( 220, 510, 390,  560, 0.95, 'bossticks_0.png', 'bossticks2_0.png', 1, 1, 1, 50, 2);   return;  //地城BOSS票=0
		case 24: return CheckImageTap( 480,  610, 610,  660, 0.96, 'spdongeon_0_2.png', 1, 1, 1, 50, 2, 0);       return;  //活動BOSS票=0 //地城BOSS票=0
		case 25: return CheckImageTap(  15,  510,  90,  570, 0.95, 'backarry2.png', 1, 1, 1, 50, 2);             return;  //戰鬥中退回按鈕

		case 26: return CheckImageTap( 640,  200, 700,  260, 0.95, 'exped_help.png', 1, 1, 1, 50, 2);        return;  //遠征問號圖示
		case 27: return CheckImageTap( 230,   10, 290,   60, 0.95, 'blitz_Bcoin.png', 1, 1, 1, 50, 2);       return;  //突襲幣圖示
		case 28: return CheckImageTap( 230,   10, 290,   60, 0.95, 'arena_Acoin.png', 1, 1, 1, 50, 2);        return;  //競技幣圖示

		case 29: return CheckImageTap( 120,   40, 190,   90, 0.95, 'dailySPgift.png', 1, 1, 1, 50, 2);        return;  //左上每日特別獎勵

		case 30: return CheckImageTap( 170, 1030, 320, 1180, 0.90, 'robotplant.png', 1, 1, 1, 50, 2);        return;  //機器人工廠字樣-底部
		case 31: return CheckImageTap( 170,  580, 320, 1180, 0.90, 'robotplant.png', 1, 1, 1, 50, 2);        return;  //機器人工廠字樣-全列表
		case 32: return CheckImageTap(  20, 1080,  85, 1180, 0.90, 'robotplantpic.png', 1, 1, 1, 50, 2);     return;  //機器人工廠圖-全列表
		case 33: return CheckImageTap(  20,  680,  85, 1180, 0.90, 'robotplantpic.png', 1, 1, 1, 50, 2);     return;  //機器人工廠圖-底部
		case 34: return CheckImageTap(   5, 1070,  55, 1190, 0.90, 'robotplantpicauto.png', 1, 1, 1, 50, 2); return;  //機器人工廠圖-底部-開自動

		case 40: return CheckImageTap( 330,  170, 390,  250, 0.90, 'reincarnationicon.png', 1, 1, 1, 50, 2); return;  //輪迴畫面中上圖示
		case 41: return CheckImageTap( 270,  980, 450, 1050, 0.90, 'reincarnationNG.png', 1, 1, 1, 50, 2);   return;  //未滿140關提示
		case 42: return CheckImageTap2( 60, 180, 650,  820, 0.90, 'ascending_prismicon2.png', 'ascending_goldicon2.png', 1, 1, 1, 50, 2, 1);   return;  //輪回畫面確認

		case 50: return checkPointcolor3(360, 640, 40, '00BEFF', 360, 660, 40, 'FFFFFF', 360, 760, 40, '6D370C'); return;   //看box廣告圖示點 ok
		// case 52: return checkPointcolor3( 15, 515, 50, '0168A5', 125, 515, 50, 'B31B0F', 240, 515, 50, '45681F'); return;   //材料地下城材料清單 新版y差+20 ok

		case 51:

			rbm.keepScreenshotPartial( 0,  490,  710,  560);
			var Img1 = rbm.findImage('list_F_icon2.png', 0.90);        //中間圖示 魔晶
			var Img2 = rbm.findImage('list_F_icon.png', 0.90);         //中間圖示 F
			// var Img2 = rbm.findImage('list_water_icon2.png', 0.90);    //中間圖示 水
			// rbm.log('list_F_icon2:', Img1);
			// rbm.log('list_F_icon:', Img2);
			// rbm.log('list_water_icon2:', Img2);
			rbm.releaseScreenshot();

			if(Img1 != undefined && Img2 != undefined){return true;}
			return false;


		case 61: return CheckImageTap( 30,  440, 64,  474, 0.90, 'guildeventicon.png', 1, 1, 1, 50, 2);       return;   //對話頻道橘色驚嘆號

		case 81: return CheckImageTap( 300,  340, 415,  380, 0.90, 'areafightchoice.png', 1, 1, 1, 50, 2);       return;   //競技場挑戰對手文字
		case 82: return CheckImageTap( 390,   70, 440,  140, 0.90, 'arena_rest.png', 1, 1, 1, 50, 2);            return;   //競技場商店文字，當日停戰

		case 91: return CheckImageTap( 600,    0, 720,   60, 0.90, 'guildbosshelpRY.png', 1, 1, 1, 50, 2);       return;   //工會BOSS,右上?圖

		case 101: return CheckImageTap( 625,  10, 710,   70, 0.90, 'mainpagebutton_bk.png', 1, 1, 1, 50, 2, 1);    return;   //右上功能圖示_模糊

	}
}

function recoNum(choiceF) {        //各項數字辨識
	if (!config.isRunning) return false;
	//console.log('各項數字辨識', choiceF);

	switch (choiceF) {
		case  1: return	num_Recognition(Game04Chkpoint[1][1], Game04Chkpoint[1][2], Game04Chkpoint[1][3], Game04Chkpoint[1][4], 0.94, 'num_gray/game4_num_blk_', 1); break;  // 位置1 數字
		case  2: return	num_Recognition(Game04Chkpoint[2][1], Game04Chkpoint[2][2], Game04Chkpoint[2][3], Game04Chkpoint[2][4], 0.94, 'num_gray/game4_num_blk_', 1); break;  // 位置2 數字
		case  3: return	num_Recognition(Game04Chkpoint[3][1], Game04Chkpoint[3][2], Game04Chkpoint[3][3], Game04Chkpoint[3][4], 0.94, 'num_gray/game4_num_blk_', 1); break;  // 位置3 數字
		case  4: return	num_Recognition(Game04Chkpoint[4][1], Game04Chkpoint[4][2], Game04Chkpoint[4][3], Game04Chkpoint[4][4], 0.94, 'num_gray/game4_num_blk_', 1); break;  // 位置4 數字

	}
}


////MINI GAME LIST

// 01. TapTheColors
// 02. SwipetoMatch
// 03. DragToAlign
// 04. TapLeasttoGreatest
// 05. TapThePair


//CHECK GAME TYPE
function gameTypeCHK() {
	if (!config.isRunning) return false;
    console.log('CheckGameType');

	gameLabel_Str = [0, 'TapTheColors', 'SwipetoMatch', 'DragToAlign', 'TapLeasttoGreatest', 'TapThePair']
	gameLabel_Sim = [0, 0.85, 0.85, 0.85, 0.85, 0.85]  //game label similarity

    gameType = 0
    for (var i = 1; i <= 5; i++) {
		if (!config.isRunning) return false;

        var Filename = 'game_label_0' + i + '.png'
        var gameLabelChk = CheckImageTap(240, 268, 840, 380, gameLabel_Sim[i], Filename, 0, 0, 100, 100, 2, 0);
        if (gameLabelChk) {
            // gameType = i;
            console.log('GameType:', i, gameLabel_Str[i]);
            return i
		}
		// sleep(200);
    }

}


////FLOW FUNCTION
function game01() {  //01. TapTheColors
	if (!config.isRunning) return false;
    console.log('game01:TapTheColors');

	for (var k = 1; k <= 5; k++) {
		for (var i = 1; i <= 9; i++) {
			if (!config.isRunning) return false;

			// 灰色:545556 (無顏色)
			var getColorChk = checkPointcolor(Game01Chkpoint[i][1], Game01Chkpoint[i][2], 30, '545556');
			if (!getColorChk) {
				console.log('Tap this point!!!!');
				console.log(k, 'times tap:', i, Game01Chkpoint[i][1], Game01Chkpoint[i][2]);


				sleep(1000);
				return false;
			}
		}
	}
}

function game02() {  //02. SwipetoMatch
	if (!config.isRunning) return false;
    console.log('game02:SwipetoMatch');

	var getChkColor1 = getPointcolor(Game02Chkpoint[1][1], Game02Chkpoint[1][2], 0);

	for (var k = 1; k <= 4; k++) {
		for (var i = 2; i <= 5; i++) {
			if (!config.isRunning) return false;

			var getColorX = Game02Chkpoint[i][1];
			var getColorY = Game02Chkpoint[i][2];

			var getColorChk = checkPointcolor(getColorX, getColorY, 30, getChkColor1);

			if (getColorChk) {
				console.log('Tap to this way!!!!');
				console.log(k, 'times swip:', Game02Chkpoint[i][3], getColorX, getColorY);


				sleep(1000);
				// break;
				return false;
			}
		}
	}
}

function game03() {  //03. DragToAlign
	if (!config.isRunning) return false;
    console.log('game03:DragToAlign');

	Game03Chkpoint[2][3] = getPointcolor(Game03Chkpoint[2][1], Game03Chkpoint[2][2], 0);

	tapUp(140, 1120, 150, 1);
	DIY_swipe(Game03Chkpoint[1][1], Game03Chkpoint[1][2], Game03Chkpoint[1][3], Game03Chkpoint[1][4], 100, 100, 1000, 0);
	
	console.log(Game03Chkpoint[2][3])
	var tapupX = Game03Chkpoint[1][3];
	var tapupY = Game03Chkpoint[1][4];

	console.log(Game03Chkpoint[1][3], Game03Chkpoint[1][4])
	for (var j = 1; j <= 8; j++) {
		for (var i = 4; i <= 6; i++) {

			Game03Chkpoint[i][3] = getPointcolor(Game03Chkpoint[i][1], Game03Chkpoint[i][2], 0);
			console.log(j, i, Game03Chkpoint[i][3], Game03Chkpoint[2][3])
			if(Game03Chkpoint[i][3] == Game03Chkpoint[2][3]) {
				if (i == 6) {
					console.log('Is right color!!!');

					tapUp(tapupX, tapupY, 150);

					sleep(1000);
					// break;
					return false;
				}

			}else {
				var tapID = j;
				console.log('263 move', j)
				DIY_swipe(tapupX, Game03Chkpoint[1][2], tapupX - Game03Chkpoint[1][5], Game03Chkpoint[1][4], 20, 100, 1000, 0);
				// tapUp(tapupX, tapupY, 150, j - 1);

				// tapupX = tapupX - Game03Chkpoint[1][5];
				sleep(1000);
				break;
			}
		}
	}
}

function game04() {  //04. TapLeasttoGreatest
	if (!config.isRunning) return false;
    console.log('game04:TapLeasttoGreatest');

	for (var i = 1; i <= 4; i++) {
		Game04Chkpoint[i][5] = recoNum(i);
	}

	// rbm.log('Game04Chkpoint 1:',Game04Chkpoint);
	console.log('value 1:', Game04Chkpoint[1][5], Game04Chkpoint[2][5], Game04Chkpoint[3][5], Game04Chkpoint[4][5]);

	Game04Chkpoint = Game04Chkpoint.sort(function(a, b) {
	  return a[5] > b[5] ? 1 : -1;
	});

	// rbm.log('Game04Chkpoint 2:',Game04Chkpoint);
	// console.log('value 2:',Game04Chkpoint[1][5], Game04Chkpoint[2][5], Game04Chkpoint[3][5], Game04Chkpoint[4][5]);

	// sleep(1000);
	// keycode('22', 500);  //for test used,  next picture.

	console.log('tap order..........');
	for (var i = 1; i <= 4; i++) {
		var tapX = Game04Chkpoint[i][1];
		var tapY = Game04Chkpoint[i][2];

		console.log('tap to:', tapX, tapY);

		sleep(1000);
	}
}

function game05() {  //05. TapThePair
	if (!config.isRunning) return false;
    console.log('game05:TapThePair');

	for (var i = 1; i <= 9; i++) {
		if (!config.isRunning) return false;
		console.log('game05:', i);
		
		Game05Chkpoint[i][3] = getPointcolor(Game05Chkpoint[i][1], Game05Chkpoint[i][2], 0);

		for (var j = i - 1; j >= 1; j--) {
			if (!config.isRunning) return false;
			if (i <= 1) {break;}

			if(Game05Chkpoint[j][3] == Game05Chkpoint[i][3]) {
				console.log('Is this the same', i, j, Game05Chkpoint[i][1], Game05Chkpoint[i][2]);


				sleep(1000);
				return false;
			}
		}
	}
}


////OLD SCRIPT CODE
function getbig(){
	if (!config.isRunning) return false;
    console.log('in: getbig()');

    checkPointcolorTap(405, 230, 50, 'E7A4A1',405, 230, 1,50,0);//點上面點數
    sleep(300)

    for(var i1 = 0; i1 < 8; ++i1){
	    if (!config.isRunning) return false;

        if (checkPointcolor(788, 1347, 50, '747474')) { //檢查那個5在不在
            tap(788, 1347, 50);
            sleep(300);

            for(var i2 = 0; i2 < 8; ++i2){
	            if (!config.isRunning) return false;

                if (checkPointcolor(626, 1592, 50, '40D293')) {//有OPEN再點上面的big
                    tap(788, 1347, 50);
                    sleep(300);
                    tap(626, 1592, 50);
                    sleep(300);

                    var i5=0;
                    for(var i3 = 0; i3 < 15; ++i3){
	                    if (!config.isRunning) return false;

                        if (checkPointcolor(824, 774, 50, 'E6E4E4')) {//檢查big是否灰色
                            for(var i4 = 0; i4 < 3; ++i4){
                                if (!config.isRunning) return false;
                                tap(830, 800, 50);
                                sleep(200);
                                tap(830, 1000, 50);
                                sleep(200);
                                tap(830, 1200, 50);
                                sleep(200);
                            }
                        }

                        if (checkPointcolor(716, 1692, 50, '40D293')) {    //檢查是否刷新
                            tap(723, 1689, 50);    //點刷新
                        }
                        sleep(1000);
                    }
                    tap(903, 515, 50);
                    break;
                }
                sleep(300);
            }
        }

        if (checkPointcolor(777,1348, 50, '747474')) {    //檢查那個5不在就是錯誤去點X
            tap(788, 1347, 50);
            sleep(300);
            break;
        }

        sleep(300);
    }
}


////MAIN FLOW FUNCTION
function main() {       //主流程
	if (!config.isRunning) return false;

	setFirstsetting()
	var waitSec = 500;
	var gameType = gameTypeCHK();

	switch (gameType) {
		case  1: {game01(); sleep(waitSec);} break;
		case  2: {game02(); sleep(waitSec);} break;
		case  3: {game03(); sleep(waitSec);} break;
		case  4: {game04(); sleep(waitSec);} break;
		case  5: {game05(); sleep(waitSec);} break;
	}
	
	if (gameType == 0){
		sleep(1000)
	}

}

////FIRST SETTING
function setFirstTimer() {   //預設值設定 - 時間相關

}

function setFirstsetting() {  //預設值設定 - 變數值相關

	Game01Chkpoint = [
		[0, 0, 0],
		[1, 320, 920],
		[2, 644, 920],
		[3, 968, 920],
		[4, 320, 1244],
		[5, 644, 1244],
		[6, 968, 1244],
		[7, 320, 1568],
		[8, 644, 1568],
		[9, 968, 1568]
	]

	Game02Chkpoint = [
		[0, 0, 0],
		[0, 420,  920, 'middle'],  //middle
		[0, 420,  500, 'up'],      //up
		[0, 420, 1780, 'down'],    //down
		[0, 140,  920, 'left'],    //left
		[0, 920,  920, 'right']    //right
	]

	Game03Chkpoint = [
		[0, 0, 0],
		[1, 40, 1120, 1000, 1120, 262],   //swip coordinate
		[2, 540,  950,  ''],   //up point middle
		[3, 540, 1310,  ''],   //down point middle
		[4, 450, 1050,  ''],   //middle point left
		[5, 540, 1050,  ''],   //middle point middle
		[6, 630, 1050,  '']    //middle point right
	]

	Game04Chkpoint = [
		[0, 0, 0, 0, 0, -1],
		[1, 230, 861, 360, 934, -1],     //區塊1 ID x1 y1 x2 y2 數值
		[2, 720, 861, 850, 934, -1],     //區塊2 ID x1 y1 x2 y2 數值
		[3, 230, 1347, 360, 1420, -1],   //區塊3 ID x1 y1 x2 y2 數值
		[4, 720, 1347, 850, 1420, -1],   //區塊4 ID x1 y1 x2 y2 數值
	]
	
	Game05Chkpoint = [
		[0, 0, 0],
		[1, 320, 920, ''],
		[2, 644, 920, ''],
		[3, 968, 920, ''],
		[4, 320, 1244, ''],
		[5, 644, 1244, ''],
		[6, 968, 1244, ''],
		[7, 320, 1568, ''],
		[8, 644, 1568, ''],
		[9, 968, 1568, '']
	]

}


////SCRIPT MENU TEST
function test(cycle){
	rbm.init();
	config.isRunning = true;               //腳本測試用function
	for(var n = 0; n <= cycle; n++) {
		if (!config.isRunning) return false;

		if (n == 0) {
			setFirstsetting();   //設定初值設定值
			setFirstTimer();     //設定初始時間值
			// commandsetting();    //初始設定值顯示
		}
		else if (n >= 1) {

			console.log('============================================================================')
			console.log('n = ', n, ', CRA 腳本開始')


            // gameTypeCHK();


			while(config.isRunning) {main();}

			sleep(1000);
			// console.log('n = ', n, ', CRA 腳本結束');
		}
	}
}


////ROBOTMON START & STOP SETTING
function stop() {
	config.isRunning=false;
}

function start() {
	rbm.init();
	config.isRunning = 1;

	
	// setFirstTimer();     //設定初始值-時間
	// setFirstsetting();   //設定初始值-數值

	while(config.isRunning) { main(); }
}